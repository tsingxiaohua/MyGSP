package DataMining_GSP;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Line2D;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import java.awt.Dialog.ModalExclusionType;
import javax.swing.JTextArea;
import java.awt.Color;
import javax.swing.JTextField;
import java.awt.Label;
import java.awt.TextArea;

import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.tools.Tool;
import javax.swing.JTextPane;

public class MyInterface extends JFrame implements ActionListener {
	private JTextField textField;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JButton button_3;
	final JTextArea textArea = new JTextArea();

	public static int minSupportCount;   //��С֧�ֶ���ֵ  

	public static int min_gap;   //ʱ����С���  

	public static int max_gap;   //ʱ�������  

	public static String str="";    //������ļ��е��ַ���
	static File file;
	public MyInterface(){

		super("GSP�㷨1.0");
		setTitle("GSP\u7B97\u6CD51.0");
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		} catch (InstantiationException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		} catch (IllegalAccessException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		} catch (UnsupportedLookAndFeelException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		//ImageIcon imageIcon = new ImageIcon(getClass().getResource("D:\\Software\\MyEclipse\\Projects\\MyGSP\\img\\cpu.png"));  // ���ñ�������ͼ��Ϊcpu.png
		//this.setIconImage(imageIcon.getImage());
		this.setResizable(false);
		this.setSize(473, 457);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		getContentPane().setLayout(null);
		textField = new JTextField();
		textField.setText("");
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setBounds(131, 283, 323, 24);
		getContentPane().add(textField);
		textField.setColumns(10);

		textField_2 = new JTextField();
		textField_2.setText("");
		textField_2.setHorizontalAlignment(SwingConstants.CENTER);
		textField_2.setColumns(10);
		textField_2.setBounds(131, 348, 322, 24);
		getContentPane().add(textField_2);

		textField_3 = new JTextField();
		textField_3.setText("");
		textField_3.setHorizontalAlignment(SwingConstants.CENTER);
		textField_3.setColumns(10);
		textField_3.setBounds(131, 315, 322, 24);
		getContentPane().add(textField_3);

		textField_4 = new JTextField();
		textField_4.setHorizontalAlignment(SwingConstants.CENTER);
		textField_4.setText("\u88AB\u9009\u62E9\u6587\u4EF6\u7684\u8DEF\u5F84");
		textField_4.setEditable(false);
		textField_4.setColumns(10);
		textField_4.setBounds(14, 244, 307, 24);
		getContentPane().add(textField_4);

		button_3 = new JButton("\u9009\u62E9\u6587\u4EF6");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser jFileChooser = new JFileChooser();
				jFileChooser.setCurrentDirectory(new File("C:\\Users\\��è��ѵ����\\Desktop"));//�ļ�ѡ�����ĳ�ʼĿ¼��ΪC��
				jFileChooser.showOpenDialog(null);
				file = jFileChooser .getSelectedFile();
				if(file!=null){
					if(file.getName().endsWith(".txt")){
						JOptionPane.showMessageDialog(null, "�ļ�ѡ��ɹ���", "��ʾ", JOptionPane.INFORMATION_MESSAGE );
						textField_4.setText(file.getAbsolutePath());
						try{
							/* ����TXT�ļ� */  
							File filename = new File(file.getAbsolutePath()); // Ҫ��ȡ����·����input��txt�ļ�  
							InputStreamReader reader = new InputStreamReader(new FileInputStream(filename)); // ����һ������������reader  
							BufferedReader br = new BufferedReader(reader); // ����һ�����������ļ�����ת�ɼ�����ܶ���������  
							String line = "";  
							while (line != null) {
								line = br.readLine(); // һ�ζ���һ������ 
								System.out.println();
								if(line!=null)
									textArea.append(line+'\n'); 
							}
							textArea.append(" ");
						}catch(Exception ee){
							ee.printStackTrace();
						}
					}
					else{
						JOptionPane.showMessageDialog(null, "�ļ���ʽ����", "����", JOptionPane.ERROR_MESSAGE);
						textField_4.setText("");
						return;
					}
				}
				else{
					JOptionPane.showMessageDialog(null, "�ļ�ѡ��ʧ�ܣ�", "����", JOptionPane.ERROR_MESSAGE );
					return;
				}				
			}

		});

		button_3.setBounds(335, 242, 120, 27);
		getContentPane().add(button_3);

		JLabel label = new JLabel("\u6700\u5C0F\u652F\u6301\u5EA6");
		label.setBounds(22, 286, 76, 18);
		getContentPane().add(label);

		JLabel label_1 = new JLabel("\u6700\u5C0F\u65F6\u95F4\u95F4\u9694");
		label_1.setBounds(14, 315, 98, 18);
		getContentPane().add(label_1);

		JLabel label_2 = new JLabel("\u6700\u5927\u65F6\u95F4\u95F4\u9694");
		label_2.setBounds(14, 348, 98, 18);
		getContentPane().add(label_2);

		JButton button = new JButton("\u8BA1\u7B97\u9891\u7E41\u96C6");
		button.setBounds(14, 382, 215, 27);
		getContentPane().add(button);
		JScrollPane jsp = new JScrollPane();
		jsp.setBounds(14, 13, 440, 218);

		jsp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

		getContentPane().add(jsp);


		jsp.setViewportView(textArea);
		textArea.setEditable(false);

		JButton button_1 = new JButton("\u5BFC\u51FA\u6587\u4EF6");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(str==""){
					JOptionPane.showMessageDialog(null, "���ȼ���Ƶ������", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				try {

					File fileText = new File(file.getParent()+"//result.txt"); //�����ļ�����   
					FileWriter fileWriter = new FileWriter(fileText);  //���ļ�д�����д����Ϣ 
					fileWriter.write(str);  //д�ļ�        
					fileWriter.close();  //�ر�  
					JOptionPane.showMessageDialog(null, "�����ļ��ɹ���", "��ʾ", JOptionPane.INFORMATION_MESSAGE);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});
		button_1.setBounds(238, 382, 215, 27);
		getContentPane().add(button_1);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double startTime = System.currentTimeMillis();    //��ȡ��ʼʱ�� 
				textArea.setText("");
				str="";
				if (file==null){
					JOptionPane.showMessageDialog(null, "����ѡ���ļ���", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				if(textField.getText().equals("")){
					JOptionPane.showMessageDialog(null, "��С֧�ֶȲ���Ϊ�գ�", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				if(Integer.parseInt(textField.getText())<=0){
					JOptionPane.showMessageDialog(null, "��С֧�ֶȱ�������������", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				if(textField_3.getText().equals("")){
					JOptionPane.showMessageDialog(null, "��Сʱ��������Ϊ�գ�", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				if(textField_2.getText().equals("")){
					JOptionPane.showMessageDialog(null, "���ʱ��������Ϊ�գ�", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				if(Integer.parseInt(textField_3.getText())<0){
					JOptionPane.showMessageDialog(null, "��Сʱ����Ӧ����0��", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				if(Integer.parseInt(textField_2.getText())<0){
					JOptionPane.showMessageDialog(null, "���ʱ����Ӧ����0��", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				if(Integer.parseInt(textField_3.getText())>Integer.parseInt(textField_2.getText())){
					JOptionPane.showMessageDialog(null, "��Сʱ����Ӧ���������ʱ������", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				minSupportCount=Integer.parseInt(textField.getText());
				min_gap=Integer.parseInt(textField_3.getText());
				max_gap=Integer.parseInt(textField_2.getText());

				GSPTool tool = new GSPTool(file.getPath(), minSupportCount, min_gap, max_gap);  
				tool.gspCalculate();
				double endTime = System.currentTimeMillis();    //��ȡ����ʱ��
				str="Ƶ����ĸ����ǣ�"+Integer.toString(tool.count)+"\r\n"+"Ƶ��������:"+"\r\n"+tool.s+"��������ʱ�䣺"+String.valueOf(endTime - startTime)+"ms";
				tool.s="";
				textArea.setText(str);//���Ƶ���������Ƶ�������ݣ���������ʱ���	
				return;
			}
		});
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new MyInterface().setVisible(true); //���������߳���ʾ������   
	}

	@Override
	public void actionPerformed(ActionEvent e) {

	}
}